CREATE PROCEDURE SYSTEM_LOBS.DELETE_LOB(IN L_ID BIGINT, IN TX_ID BIGINT)
  SPECIFIC DELETE_LOB_10030
  LANGUAGE SQL
  NOT DETERMINISTIC
  MODIFIES SQL DATA
  NEW SAVEPOINT LEVEL BEGIN ATOMIC INSERT INTO SYSTEM_LOBS.BLOCKS (BLOCK_ADDR, BLOCK_COUNT, TX_ID) (SELECT
                                                                                                      BLOCK_ADDR,
                                                                                                      BLOCK_COUNT,
                                                                                                      TX_ID
                                                                                                    FROM
                                                                                                      SYSTEM_LOBS.LOBS
                                                                                                    WHERE LOBS.LOB_ID =
                                                                                                          L_ID);
  DELETE FROM SYSTEM_LOBS.LOBS
  WHERE LOBS.LOB_ID = L_ID;
  DELETE FROM SYSTEM_LOBS.PARTS
  WHERE LOB_ID = L_ID;
  DELETE FROM SYSTEM_LOBS.LOB_IDS
  WHERE LOB_IDS.LOB_ID = L_ID;
END
